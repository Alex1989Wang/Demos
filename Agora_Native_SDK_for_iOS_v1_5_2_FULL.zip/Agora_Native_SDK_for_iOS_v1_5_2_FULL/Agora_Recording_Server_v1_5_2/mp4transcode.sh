#!/bin/bash

fileName="$1/recording-done.txt"
touch $fileName
