This sample program demonstrates compression request and response payload and provides a way to perform simple
performance tests altering the payload compression.

If you want to try a payload specific to your problem domain, replace the data.xml file with a file with the same name containing your
sample data.
