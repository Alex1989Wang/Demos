//
//  AppDelegate.h
//  PostCompress
//
//  Created by Jack Cox on 3/3/12.
//  
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
