//
//  XDGiftView.h
//  testGift
//
//  Created by 形点网络 on 16/6/30.
//  Copyright © 2016年 形点网络. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDGiftView : UIView

#warning - 把男女嘉宾主持人数据（模型）放在一个数组中，传递过来

#warning - 接受礼物数据

#warning - 接受money数据
@end
