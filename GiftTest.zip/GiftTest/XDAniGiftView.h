//
//  XDAniGiftView.h
//  testGift
//
//  Created by 形点网络 on 16/7/1.
//  Copyright © 2016年 形点网络. All rights reserved.
//

#import <UIKit/UIKit.h>


@class XDGiftGroup;
@class XDAniGiftView;

@protocol XDAniGiftViewDelegate <NSObject>

@optional
/**
 *  The delegate should change the "should" parameter to notify 
 *  the animation view to be delegated when to stop animation;
 *
 *  @param should The parameter indicates where the animation for this animation view should stop;
 */
- (BOOL)aniGiftViewShouldStopAnimation:(XDAniGiftView *)aniGiftView presentGiftGroup:(XDGiftGroup *)present;

@end

@interface XDAniGiftView : UIView

/* view outlets */
@property (weak, nonatomic) IBOutlet UIImageView *giftImageView;      // 礼物的图片
@property (weak, nonatomic) IBOutlet UIImageView *sendUserImageView;  // 送礼物人 头像
@property (weak, nonatomic) IBOutlet UILabel *sendUserNameLabel;      // 送礼物人的名字
@property (weak, nonatomic) IBOutlet UILabel *acceptUserNameLabel;   // 收礼物人的名字
@property (nonatomic, assign) NSInteger acceptType;           // 1 主持人 2 男嘉宾 3 女嘉宾

@property (nonatomic, assign) NSInteger rowNum; // 礼物横幅的行数

@property (nonatomic, strong) XDGiftGroup *giftModel;    // 需要执行动画的礼物
@property (nonatomic, strong) NSString *animateGroup_id;  // 动画的group_id

@property (nonatomic, assign, getter=isRunning) BOOL running;  // 该View是否在动画

@property (nonatomic, weak) id <XDAniGiftViewDelegate> delegate;

+ (instancetype)aniGiftView;
- (void)continueAnimationWithGiftGroup:(XDGiftGroup *)continuedGiftGroup;

@end
