//
//  XDLLTestGiftViewController.m
//  seeYouTime
//
//  Created by 形点网络 on 16/7/27.
//  Copyright © 2016年 形点网络. All rights reserved.
//

#import "XDGiftViewController.h"
#import "XDGiftView.h"
#import "XDAniGiftView.h"
#import "XDGiftGroup.h"
#import "XDAniGiftView.h"
#import "XDGiftGroupBuffer.h"

#define ANI_VIEW_COUNT 3

@interface XDGiftViewController ()<XDAniGiftViewDelegate>

/* the gift group id */
@property (nonatomic, assign) NSInteger gr_id;

/* the three animation banner views */
@property (nonatomic, strong) NSMutableArray *aniViews;
@property (nonatomic, weak) XDAniGiftView *topView;
@property (nonatomic, weak) XDAniGiftView *middleView;
@property (nonatomic, weak) XDAniGiftView *bottomView;

@end

@implementation XDGiftViewController


- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.view.backgroundColor = XDGlobalColor;
    self.navigationController.navigationBar.hidden = YES;
    UIButton *back = [UIButton buttonWithType:UIButtonTypeCustom];
    [back setTitle:@"返回" forState:UIControlStateNormal];
    back.backgroundColor = [UIColor blackColor];
    [back addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    back.frame = CGRectMake(XDScreenW - 50, 30, 100, 30);
    [self.view addSubview:back];
    
    
    UIButton *giftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [giftBtn setTitle:@"送礼物" forState:UIControlStateNormal];
    giftBtn.backgroundColor = [UIColor blackColor];
//    [giftBtn addTarget:self action:@selector(giftClick) forControlEvents:UIControlEventTouchUpInside];
    giftBtn.frame = CGRectMake(XDScreenW * 0.5+30, XDScreenH * 0.5-50, 100, 30);
    [self.view addSubview:giftBtn];
    
    UIButton *notBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [notBtn setTitle:@"接到广播通知" forState:UIControlStateNormal];
    notBtn.backgroundColor = [UIColor blackColor];
    [notBtn addTarget:self action:@selector(giftsFromBroadcast) forControlEvents:UIControlEventTouchUpInside];
    notBtn.frame = CGRectMake(XDScreenW * 0.5 - 150, XDScreenH * 0.5-50, 100, 30);
    [self.view addSubview:notBtn];
    

    //instantiate the gift banners
    for (NSUInteger i = 0; i < ANI_VIEW_COUNT; i++) {
        XDAniGiftView *aniView = [XDAniGiftView aniGiftView];
        aniView.rowNum = i+1;
        aniView.delegate = self;
        [self.aniViews addObject:aniView];
        [self.view addSubview: aniView];
    }
    
    //assgin values;
    self.topView = self.aniViews[0];
    self.middleView = self.aniViews[1];
    self.bottomView = self.aniViews[2];
    
    //register as the buffer's observer;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNewlyAddedGiftModel:) name:BufferAddedNewGiftGroup object:nil];
}

- (void)giftsFromBroadcast    // 模拟收到礼物通知      ---  接到礼物通知的时候还要记录在哪个总队列中   **************
{
    //git test image - from 1 - 5;
    //1. instantiate three groups of git groups
    NSInteger gr_id = 1;
    
    XDGiftGroup *model1 = [[XDGiftGroup alloc] init];
    model1.sendName = [NSString stringWithFormat:@"%ld-送礼人",gr_id];
    model1.acceptName = [NSString stringWithFormat:@"%ld-收礼人",gr_id];;
    model1.giftImage = [UIImage imageNamed:[NSString stringWithFormat:@"%ld",gr_id]];
    model1.group_id = [NSString stringWithFormat:@"%ld",gr_id];
    model1.acceptType = arc4random_uniform(2) + 2;                                  //randomize the accept type;
    model1.count = 5;
    
    XDGiftGroup *model2 = [[XDGiftGroup alloc] init];
    model2.sendName = [NSString stringWithFormat:@"%ld-送礼人",gr_id+1];
    model2.acceptName = [NSString stringWithFormat:@"%ld-收礼人",gr_id+1];;
    model2.giftImage = [UIImage imageNamed:[NSString stringWithFormat:@"%ld",gr_id+1]];
    model2.group_id = [NSString stringWithFormat:@"%ld",gr_id+1];
    model2.acceptType = arc4random_uniform(2) + 2;
    model2.count = 10;
    
    XDGiftGroup *model3 = [[XDGiftGroup alloc] init];
    model3.sendName = [NSString stringWithFormat:@"%ld-送礼人",gr_id+2];
    model3.acceptName = [NSString stringWithFormat:@"%ld-收礼人",gr_id+2];;
    model3.giftImage = [UIImage imageNamed:[NSString stringWithFormat:@"%ld",gr_id+2]];
    model3.group_id = [NSString stringWithFormat:@"%ld",gr_id];
    model3.acceptType = arc4random_uniform(2) + 2;
    model3.count = 13;
    
    //2 add them to the broadcast gift groups
    [[XDGiftGroupBuffer sharedBuffer] bufferAddGiftGroup:model1];
    [[XDGiftGroupBuffer sharedBuffer] bufferAddGiftGroup:model2];
    [[XDGiftGroupBuffer sharedBuffer] bufferAddGiftGroup:model3];
}

#pragma mark - dispatch newly added gift group
- (void)handleNewlyAddedGiftModel:(NSNotification *)noti {
    //1.0 fetch the first group
    XDGiftGroup *giftGroup = [[XDGiftGroupBuffer sharedBuffer] fetchFirstGiftGroup];
    
    if (nil == giftGroup) { //in fact, this will never happen;
        return;
    }
    
    //2.0 search for the suitable aniGiftView
    XDAniGiftView *giftView = [self getGiftViewSlot:giftGroup.group_id];
    if (nil == giftView) {          // the gift group should be put back;
        [[XDGiftGroupBuffer sharedBuffer] bufferAddGiftGroup:giftGroup];
    }else {                         // should start animation
        //2.1 assign
        giftView.giftModel = giftGroup;
        
        //2.2 delete
        [[XDGiftGroupBuffer sharedBuffer] deleteGiftGroup:giftGroup];
    }
}


#pragma mark - XDAniGiftViewDelegate methods
- (BOOL)aniGiftViewShouldStopAnimation:(XDAniGiftView *)aniGiftView presentGiftGroup:(XDGiftGroup *)present {
    
    //1.0 try to fetch a gift group with the specified group_id;
    XDGiftGroup *fetchResult = [[XDGiftGroupBuffer sharedBuffer] fetchGiftGroupWithID:present.group_id];
    return (nil == fetchResult) ? YES : NO;
}

// 获取适合的view
- (XDAniGiftView *)getGiftViewSlot:(NSString *)grp_id
{
    for (NSUInteger index = 0; index < ANI_VIEW_COUNT; index++) {
        XDAniGiftView *ani = self.aniViews[index];
        if (!ani.isRunning || [ani.animateGroup_id isEqualToString:grp_id])
            return ani;
        
//        if (!ani.isRunning) {
//            return ani;
//        }else if ([ani.animateGroup_id isEqualToString:grp_id]) {
//            return ani;
//        }
    }
    
    return nil;
}



#pragma mark - lazy loading
-(NSMutableArray *)aniViews
{
    if (_aniViews == nil) {
        
        _aniViews = [NSMutableArray array];
    }
    
    return _aniViews;
}

#pragma mark - other test config
- (void)back
{
    self.navigationController.navigationBar.hidden = NO;
    [self.navigationController popViewControllerAnimated:YES];
}

@end
