//
//  XDAniGiftView.m
//  testGift
//
//  Created by 形点网络 on 16/7/1.
//  Copyright © 2016年 形点网络. All rights reserved.
//

#import "XDAniGiftBanner.h"
#import "XDGiftGroup.h"
#import "XDNumberAnimationView.h"

#define kBannerHeight 50.f
#define kBannerOriginalWidth 205.f
#define kDefaultDigitImageViewCount 2
#define kAniNumWidth 16.f
#define kAniNumHeight 24.f

/* 消失动画时间 */
#define kNormalWaitingDuration 2.0
#define kShortWaitingDuration 0.8
#define kDisappearingDuration 0.3
#define kNumAnimationTimeGap 0.3

/* 所有的数值差都统一在 0.5秒内完成 - 需要显示多个数字的时候，加快重画 */
#define kTotalNumAniDuration 0.5

@interface XDAniGiftBanner ()

/* view outlets */
@property (weak, nonatomic) IBOutlet UIImageView *giftImageView;      // 礼物的图片
@property (weak, nonatomic) IBOutlet UIImageView *sendUserImageView;  // 送礼物人头像
@property (weak, nonatomic) IBOutlet UILabel *sendUserNameLabel;      // 送礼物人的名字
@property (weak, nonatomic) IBOutlet UILabel *acceptUserNameLabel;   // 收礼物人的名字
/* 礼物的接受者 */
// 1 主持人 2 男嘉宾 3 女嘉宾
@property (nonatomic, assign) XDGiftReceiverType acceptType;

/* 数字动画计时器 */
@property (nonatomic, weak) NSTimer *aniTimer;

/* 完成数字动画后等待 timer */
@property (nonatomic, weak) NSTimer *waitingTimer;

/* 动画数值的总数 */
@property (nonatomic, assign) NSUInteger aniNumTotal;

/* 正在动画的数字 */
@property (nonatomic, assign) NSUInteger aniNum;

/* 做数字动画的view */
@property (nonatomic, strong) XDNumberAnimationView *numAniView;

@end


@implementation XDAniGiftBanner

#pragma mark - Initialization and UI-related;

/**
 *  Return the git view to display animation;
 *
 *  @return The gift view;
 */
+ (instancetype)aniGiftBanner
{
    return [[[NSBundle mainBundle] loadNibNamed:@"XDAniGiftBanner" owner:nil options:nil] lastObject];
}

- (void)awakeFromNib
{
    //设置banner的尺寸和外观
    [self configureBanner];
    
    //添加一个数字动画view
    [self addSubview:self.numAniView];
    
    //register as observer;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(giftDisappearingCurveAnimation) name:@"giftDisappearingCurveAnimation" object:nil];
}

/**
 *  设置banner的初始尺寸
 *
 */
- (void)configureBanner {
    //1.0 设置banner高度和初始宽度
    CGRect bannerBounds = self.bounds;
    bannerBounds.size.height = kBannerHeight;
    bannerBounds.size.width = kBannerOriginalWidth;
    self.bounds = bannerBounds;
    
    //2.0 透明背景
    [self setBackgroundColor:[UIColor clearColor]];
}

/**
 *  根据需要显示的数值总数（总数>=正在显示的数）来resize礼物横幅banner
 *  小于10的数值按前面用0补齐 - 加上0位和前面显示的X
 */
- (void)resizeBannerWidth {
    NSUInteger numCount = [NSString stringWithFormat:@"%lu", self.giftModel.count].length;
    CGFloat resizedWidth = self.bounds.size.width;
    
    if (numCount < 2) {
        resizedWidth = (numCount + 2) * kAniNumWidth + self.bounds.size.width;
    }else {
        resizedWidth = (numCount + 1) * kAniNumWidth + self.bounds.size.width;
    }
    
    CGRect bounds = self.bounds;
    bounds.size.width = resizedWidth;
    self.bounds = bounds;
}


/**
 *  显示礼物的信息
 *
 */
- (void)setGiftModel:(XDGiftGroup *)giftModel
{
    //1.0 赋值和显示
    _giftModel = giftModel;
    
    self.giftImageView.image = giftModel.giftImage;  // 礼物图片
    self.sendUserImageView.image = giftModel.senderImage;  // 送礼的人头像
    self.sendUserNameLabel.text = giftModel.senderName;  // 送礼的人名
    self.acceptUserNameLabel.text = giftModel.receiverName;  // 收礼的人名
    self.acceptType = giftModel.receiverType; // 接受者类型
}


#pragma mark - Animation related;

/**
 *  重置现在正在动画的gift group的总数
 *
 */
- (void)resetAniTotalCount:(XDGiftGroup *)group {
    
    //1.0 无需重新刷新礼物信息 - 直接修改需要显示数值总数
    self.giftModel.count = group.count;
    _aniNumTotal = group.count;
    
    //2.0 取消waiting timer (如果有waiting timer - 动画数字已经自增过一次了）
    if (_waitingTimer != nil) {
        [_waitingTimer invalidate];
        _waitingTimer = nil;
        _aniNum = _aniNum - 1;
    }
    
    //3.0 重新开始动画 - 3.1 现在正在动画（有aniTimer)取消timer
    if (_aniTimer != nil) {
        [_aniTimer invalidate];
        _aniTimer = nil;
    }
    //3.2 开始动画
    [self configureProperAnimationSpeed];
}


/**
 *  赋值gift group,开始动画
 *
 */
- (void)startAnimationWithGiftGroup:(XDGiftGroup *)group {
    //0.0 赋值显示礼物信息 - 设置总数
    self.giftModel = group;
    _aniNumTotal = group.count;
    
    //1.0 设置banner状态；
    _disappearing = NO;
    
    //2.0 调整banner大小适应动画数字view大小 - 根据总数
    [self resizeBannerWidth];
    
    //3.0 根据总数和现在显示差判断动画类型 - 开始动画
    [self configureProperAnimationSpeed];
}

- (void)configureProperAnimationSpeed {
    CGFloat timerInterval = kTotalNumAniDuration / (_aniNumTotal - _aniNum);
    _aniTimer = [NSTimer scheduledTimerWithTimeInterval:timerInterval target:self selector:@selector(aniViewStartAnimation:) userInfo:nil repeats:YES];
}

/**
 *  绘制动画数值 - 先将需要显示数值+1
 *  也就是从1开始绘制
 *  _aniNum <= _aniNumTotal - 还没有到要显示的总数 - 显示当前的动画数字
 *  else - 已经完成了该组动画的显示 - 判断要使用什么类型的消失动画
 *
 */
- (void)aniViewStartAnimation:(NSTimer *)aniTimer
{
    _aniNum ++;
    
    if (_aniNum <= _aniNumTotal) {
       
        [_numAniView drawNum:_aniNum withSizeChange:(aniTimer.timeInterval >= 0.45)];
        
    }else {
        
        /**
         *  进入消失等待状态 - 1.0 取消动画timer； 2.0 启动等待timer2.0s
         */
        [self.aniTimer invalidate];
        self.aniTimer = nil;
        
        CGFloat disappearDelayDuration = kNormalWaitingDuration - kDisappearingDuration;
        self.waitingTimer = [NSTimer scheduledTimerWithTimeInterval:disappearDelayDuration target:self selector:@selector(launchDisappearAnimation) userInfo:nil repeats:NO];
    }
}

- (void)launchDisappearAnimation{
#warning 先设计为全部淡出消失 统一时间为2s
    //2.0 开始消失 - 标记消失；取消数字动画timer；
    _disappearing = YES;
    
    //3.0 开始消失动画
    [UIView animateWithDuration:kDisappearingDuration animations:^{
        self.alpha = 0.f;
    } completion:^(BOOL finished) {
        
        //3.1 开启完成消失回调
        if ([self.delegate respondsToSelector:@selector(giftBannerDidFinishDisappearing:)]) {
            [self.delegate giftBannerDidFinishDisappearing:self];
        }
    }];
}



/**
 *  礼物掉落抛物线动画
 */
- (void)giftDisappearingCurveAnimation
{
    if (self.acceptType == 1) return;   // 主持人没有动画
    
    UIImageView *imageView = [[UIImageView alloc] init];
    
    imageView.image = self.giftImageView.image;
    imageView.width = self.giftImageView.width;
    imageView.height = self.giftImageView.height;
    imageView.x = self.giftImageView.x;
    imageView.y = self.y;
    [[UIApplication sharedApplication].keyWindow addSubview:imageView];
    
    // 执行动画
    if (self.acceptType == 3) {   // 女嘉宾右边掉落
        
        CAKeyframeAnimation *ani = [CAKeyframeAnimation animation];
        
        UIBezierPath *path = [UIBezierPath bezierPath];
        [path moveToPoint:imageView.center];
        [path addQuadCurveToPoint:CGPointMake(XDScreenW * 0.75, XDScreenH  * 0.7) controlPoint:CGPointMake(XDScreenW,imageView.y)];
        ani.keyPath=@"position";
        ani.path = path.CGPath;
        ani.duration = 1;
        ani.repeatCount = 1;
        ani.removedOnCompletion=NO;
        ani.fillMode=kCAFillModeForwards;
        [imageView.layer addAnimation:ani forKey:nil];
    }
    
    if (self.acceptType == 2) {   // 男嘉宾左边掉落
        
        CAKeyframeAnimation *ani1 = [CAKeyframeAnimation animation];
        
        UIBezierPath *path1 = [UIBezierPath bezierPath];
        [path1 moveToPoint:imageView.center];
        [path1 addQuadCurveToPoint:CGPointMake(XDScreenW * 0.25, XDScreenH  * 0.7) controlPoint:CGPointMake(0,imageView.y)];
        ani1.keyPath=@"position";
        ani1.path = path1.CGPath;
        ani1.duration = 1;
        ani1.repeatCount = 1;
        ani1.removedOnCompletion=NO;
        ani1.fillMode=kCAFillModeForwards;
        [imageView.layer addAnimation:ani1 forKey:nil];
    }
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [imageView removeFromSuperview];
    });
    
}

#pragma mark - 懒加载一个数字动画View
- (XDNumberAnimationView *)numAniView {
    if (nil == _numAniView) {
        _numAniView = [[XDNumberAnimationView alloc] initWithPosition:CGPointMake(CGRectGetMaxX(self.giftImageView.frame) + 10.f, 0.5 * (self.bounds.size.height - kAniNumHeight))];
    }
    return _numAniView;
}


@end


