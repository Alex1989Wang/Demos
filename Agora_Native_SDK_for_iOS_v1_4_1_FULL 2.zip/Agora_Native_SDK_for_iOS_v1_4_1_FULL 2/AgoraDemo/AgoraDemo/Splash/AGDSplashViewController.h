//
//  AGDSplashViewController.h
//  AgoraDemo
//
//  Created by apple on 15/10/20.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGDSplashViewController : UIViewController

@end
