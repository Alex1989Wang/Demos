//
//  XDVerticalButton.h
//  
//
//  Created by 形点网络 on 16/6/29.
//
//

#import <UIKit/UIKit.h>

@interface XDVerticalButton : UIButton

@end
